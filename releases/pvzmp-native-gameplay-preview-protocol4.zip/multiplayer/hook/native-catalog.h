#pragma once
namespace NativeCatalog {
// Native seed/card IDs. Terrain, upgrade and layered plants need additional
// state replication and are deliberately unavailable on this daylight board.
constexpr int ZombieCards[]={60,61,62,63,67,69};
constexpr int ZombieTypes[]={0,2,3,4,7,6};
inline bool plant(int type){
    switch(type){
    case 0:case 1:case 2:case 3:case 4:case 5:case 6:case 7:
    case 17:case 18:case 20:case 21:case 22:case 23:case 25:case 26:
    case 27:case 28:case 29:case 31:case 32:case 34:case 36:case 37:case 38:case 39:return true;
    default:return false;
    }
}
inline int zombieType(int card){for(int i=0;i<6;++i)if(card==ZombieCards[i])return ZombieTypes[i];return -1;}
inline bool card(int role,int type){return role?zombieType(type)>=0:plant(type);}
inline int chooserCard(int role,int index){return role?(index>=0 && index<6?ZombieCards[index]:-1):index;}
inline unsigned deckSize(int role){return role?3:6;}
struct Deck {
    int types[6]={-1,-1,-1,-1,-1,-1};unsigned count=0,mask=0;
    bool set(int role,unsigned index,unsigned total,int type){
        if(total!=deckSize(role) || index>=total || !card(role,type))return false;
        if((mask&(1u<<index)) && types[index]!=type)return false;
        for(unsigned i=0;i<total;++i)if(i!=index && (mask&(1u<<i)) && types[i]==type)return false;
        count=total;types[index]=type;mask|=1u<<index;return true;
    }
    bool complete()const{return count && mask==(1u<<count)-1;}
    int find(int type)const{for(unsigned i=0;i<count;++i)if((mask&(1u<<i)) && types[i]==type)return (int)i;return -1;}
};
}
