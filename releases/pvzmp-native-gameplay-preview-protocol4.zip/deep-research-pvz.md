# Исследование: как добавить мультиплеер в оригинальный Plants vs. Zombies

## Executive summary

Под «оригинальным PvZ» ниже я понимаю PC-ветку Plants vs. Zombies 2009 года на Windows, прежде всего классическую 32-битную сборку 1.0.0.1051 и GOTY-линейку 1.2.x; точные адреса функций, layout классов и пригодность готовых хуков зависят от конкретного `PlantsVsZombies.exe`. Это не косметическая деталь: существующий открытый сетевой мод **Plants-vs.-Zombies-Online-Battle** привязан именно к китайской `1.0.0.1051` с конкретным MD5, а современные реконструкции отдельно учитывают различия между standalone GOTY 1.2.0.1073 и Steam GOTY 1.2.0.1096. citeturn342395search0turn594338search5

Главный вывод исследования: **создавать сетевой мод для оригинального PvZ технически реально, и это уже было доказано на практике**. Наиболее важный precedent — открытый проект Zhuagenborn/Plants-vs.-Zombies-Online-Battle: C++ DLL внедряются в оригинальный процесс, ставят inline hooks на функции создания растений/зомби и события уровня, а обмен между двумя процессами идет по TCP; игрок за растения фактически выступает сервером, игрок за зомби — клиентом. citeturn227627search6turn342395search0

Для нового проекта я бы **не начинал с полной синхронизации памяти или rollback**. PvZ — детерминированная в значительной части, сравнительно медленная игра с небольшим количеством дискретных пользовательских команд. Поэтому лучший MVP — host-authoritative/event replication: клиент передает не состояние каждого объекта каждый кадр, а команды вроде `PlacePlant`, `SpawnZombie`, `Shovel`, `SelectSeed`; хост проверяет их, исполняет локально и рассылает подтвержденные события. Периодически хост отправляет checksum или компактный snapshot ключевого состояния для обнаружения и исправления рассинхронизации. Это значительно проще, надежнее и безопаснее, чем пытаться немедленно сделать deterministic lockstep или rollback.

Еще один важный вывод: **официальный Replanted не имеет настоящего сетевого PvP-кода, который можно было бы просто воспроизвести**. Официально игра содержит локальный co-op и локальный Vs.; начиная с patch 1.4.0 Steam-версия поддерживает Remote Play Together, то есть игра исполняется только у хоста, а Steam стримит изображение/звук второму игроку и возвращает его ввод. EA прямо описывает multiplayer как local co-op / PvP, а официальный патчноут объясняет Remote Play как способ играть в эти локальные режимы через стриминг. Следовательно, у Replanted нет собственного gameplay-протокола, matchmaking-сервера или сетевой authoritative simulation, которые можно было бы декомпилировать как эталон. citeturn220288search0turn220288search2turn220288search3turn227627search0

При этом существует отдельный открытый **ReplantedOnline**, который уже делает то, что официальная игра не делает: добавляет P2P online Versus через MelonLoader/Harmony, Steamworks matchmaking, сетевые объекты, RPC и бинарную сериализацию. Этот проект особенно полезен как архитектурный референс для того, **какие PvZ-события необходимо синхронизировать**, хотя его код нельзя перенести напрямую в PvZ 2009 из-за совершенно другого runtime и способа модификации. citeturn596546view0turn981322search0

Практически я рекомендую две последовательные цели. Сначала сделать **локальный двухигроковый режим** поверх восстановленного/декомпилированного кода или DLL-хуков — это заставит правильно разделить `PlayerInput`, ресурсы, курсоры и полномочия игроков без сетевых ошибок. Затем заменить второй локальный input source на сетевой transport. Для Internet MVP проще всего использовать либо TCP/UDP с ручным вводом IP, либо независимую библиотеку GameNetworkingSockets; Steam P2P/SDR стоит рассматривать позднее, потому что полноценный Steamworks/SDR предполагает приложение и настройки на стороне Steamworks, которыми автор неофициального мода для чужого AppID обычно не управляет. citeturn558851search1turn558851search5

## Архитектура оригинального PvZ и поверхность для моддинга

PC-версия PvZ построена на C++-движке PopCap **SexyAppFramework / PopCap Games Framework**. В реконструированном исходном коде видны отдельные слои `SexyAppFramework`, `Sexy.TodLib` и собственно игровая логика `Lawn`; центральным объектом игрового уровня является `Board`, рядом существуют `Plant`, `Zombie`, `Projectile`, `Coin`, `GridItem`, UI-компоненты и `LawnApp`. Современный проект re-plants-vs-zombies прямо описывает SexyAppFramework как старый C++ framework и восстанавливает GOTY-функциональность поверх более ранней декомпиляции. citeturn596546view1turn540109search11turn540109search17turn540109search20

Это важное свойство архитектуры: PvZ не является data-driven игрой в современном смысле. Многие существенные правила — стоимость растений, AI, выбор целей, таймеры, создание объектов, игровые режимы — находятся в нативном C++ коде. Поэтому замены ресурсов достаточно для texture/audio mods, но полноценный multiplayer требует изменения исполняемой логики. Именно поэтому серьезные проекты либо реконструируют исходники, либо вмешиваются в машинный код через hooks. citeturn596546view1turn227627search20turn112307search26

Ресурсная часть игры организована вокруг `main.pak`. Декомпиляция содержит `PakInterface`, который memory-map'ит pak-файл и строит таблицу `filename → start offset/size`; поверх нее game framework предоставляет file-like API. Внутри PvZ используются папки ресурсов вроде `images`, `sounds`, `properties`, `compiled` и другие. При работе с реконструированными версиями можно использовать как `main.pak`, так и loose resources. citeturn540109search2turn540109search5turn540109search12

`properties/resources.xml` описывает ресурсы и используется `ResourceManager`; моддинговые forks прямо документируют добавление собственных images, particles, texts и sounds через manifest. А `userN.dat` — отдельный бинарный пользовательский save format; исходный `PlayerInfo.cpp` сериализует многочисленные значения через `SyncLong` и формирует путь `userdata/user%d.dat`. citeturn540109search9turn540109search7

Практически полезно разделять три класса модификации:

| Уровень | Что меняется | Подходит для multiplayer |
|---|---|---|
| Assets / `.pak` | графика, звук, часть properties и animation resources | почти нет |
| Runtime memory patches | значения, переходы, адреса функций, ASM injections | да, но хрупко |
| DLL / reconstructed source | новые режимы, input, networking, serialization | оптимально |

В моддинге PvZ сейчас существуют две хорошо различимые школы. Первая — **native/reconstruction**: re-plants-vs-zombies, Stable-Decompile, ResoddedFramework и PvZ-Portable дают C++ исходную структуру игры и собираются через CMake/Visual Studio/Ninja. ResoddedFramework позиционирует себя именно как modding base и уже поддерживает отдельные mod `.pak`/folders. citeturn596546view1turn596546view2turn594338search19

Вторая школа — **инъекция в оригинальный binary**. Например, `pvz-lua-modloader` использует C++ библиотеку `mem.dll`, runtime memory lookup, byte patching и ASM injection, предоставляя Lua API поверх них. Другой свежий framework — `pvz-traditional-mod` — строит Win32 DLL/EXE hook-моды и использует MinHook. citeturn112307search26turn342395search12

Именно поэтому для multiplayer предпочтительны C++20, CMake и Visual Studio с `-A Win32`, если цель — работа с оригинальным x86 executable. Lua или C# можно использовать для UI, launcher и конфигурации, но latency-sensitive hooks и ABI-совместимость проще держать в C++. Открытый Online-Battle также собирается Visual Studio 2022 + CMake как Win32. citeturn227627search6

Российских первичных технических источников немного; русскоязычные сайты в основном описывают распаковку `main.pak` и установку готовых модов. Например, русскоязычные материалы Playground описывают распаковку/перепаковку `main.pak`, а Gitverse зеркалит историческую декомпиляцию. Для reverse engineering лучше опираться на исходные GitHub-репозитории. citeturn112307search13turn112307search21

## Уже существующий multiplayer для классического PvZ

Самый важный проект — **Zhuagenborn/Plants-vs.-Zombies-Online-Battle**. Это не remake и не отдельная игра: проект именно модифицирует PvZ через reverse engineering, inline hooks и DLL injection. При сборке создаются `plant.dll` и `zombie.dll`; DLL внедряется в `PlantsVsZombies.exe` при старте. citeturn227627search6turn342395search0

Ограничение проекта одновременно показывает главную инженерную проблему такого пути: он работает только с PvZ `1.0.0.1051` Chinese и даже проверяет конкретный executable checksum. Причина очевидна из архитектуры: hook targets и offsets вычислены для конкретного машинного кода, а не для абстрактного API. citeturn342395search0

Проект преобразует `I, Zombie Endless` в двухигроковый онлайн-режим. Plant side запускается как server, Zombie side как client. Настройки задаются через `online_config.ini` с IP и port; transport реализован собственными `Socket`, `TcpSocket`, `Listener` и `Packet`. То есть сетевой слой — обычный TCP поверх IPv4 по умолчанию, с возможностью собрать IPv6-вариант. citeturn227627search6turn342395search0

Наиболее важен не транспорт, а места hooks. Диаграмма проекта показывает `BeforeLoadLevel`, `AfterLoadLevel`, `InitSlots`, `CreatePlant`, `CreateZombie` и `LevelEnd`; `CreatePlant` и `CreateZombie` связаны одновременно с игровым `State` и `Packet`. Это фактически **event replication**, а не передача всей памяти игры. citeturn227627search6

Архитектуру можно представить так:

```mermaid
flowchart LR
    A["PvZ process: Plants"] --> B["Injected plant.dll"]
    B --> C["Inline hooks"]
    C --> D["CreatePlant / CreateZombie / LevelEnd"]
    D --> E["Packet serializer"]
    E --> F["TCP socket"]
    F --> G["TCP socket"]
    G --> H["Injected zombie.dll"]
    H --> I["Hooks into second PvZ process"]
```

В README прямо перечислены известные проблемы: иногда игра падает при создании зомби, а непустой progress `I, Zombie Endless` может приводить к разным battlefield state у двух игроков. Это наглядно демонстрирует типичную проблему event-only synchronization: если начальное состояние не идентично или какое-то локальное событие не реплицировано, клиенты начинают расходиться. citeturn342395search0

Второй интересный пример — Community/DLC Mod, который добавил PC-версию Versus; публичные пользовательские материалы указывают, что его multiplayer локальный, с двумя input schemes, а не Internet networking. Он полезен как evidence того, что **console-style two-player rules/UI можно перенести на PC game loop**, но не как образец сетевого transport. citeturn227367search2turn227367reddit40

Отдельно существует `PvZ-Portable-multiplayer` и связанные forks PvZ-Portable. Это уже не binary patch оригинального `.exe`, а реконструированный C++ codebase, поэтому такой путь архитектурно чище: вместо поиска адреса `Board::AddPlant` можно менять сам C++ метод. Проект PvZ-Portable ориентирован на совместимость с ресурсами оригинального GOTY и переносит game logic в современный C++ codebase. citeturn227367search1turn594338search5

Если конечная цель — «мод, запускающийся поверх оригинального `PlantsVsZombies.exe`», Online-Battle — лучший reference. Если цель допускает replacement executable при наличии легально купленных assets, Resodded/PvZ-Portable/re-plants-vs-zombies дают намного более поддерживаемую основу. citeturn596546view1turn596546view2turn594338search5

## Что на самом деле делает multiplayer в Replanted

На этом месте важно исправить распространенное предположение. **Plants vs. Zombies: Replanted не реализует native Internet multiplayer.** Официальная EA-страница описывает co-op и PvP как local modes; Steam launch announcement также называет multiplayer локальным. citeturn220288search2turn220288search1

В update 1.4.0 от 18 ноября 2025 года Windows/Steam-версия получила **Steam Remote Play Together**. Сам патчноут формулирует это как способ играть в local Co-op и Vs. «как если бы игроки находились в одной комнате»; Player 2 все равно должен использовать controller, действует локальный лимит двух игроков, а качество зависит от Internet connection хоста. citeturn220288search0

Steam объясняет механику Remote Play Together следующим образом: игра запускается у хоста, Steam передает удаленным игрокам video/audio, а обратно получает controller/keyboard/mouse input. Это streaming, а не сетевой gameplay synchronization. citeturn220288search4turn227627search0

Следствия для нужных вам характеристик:

| Характеристика Replanted | Фактическая реализация |
|---|---|
| Gameplay protocol | отсутствует как отдельный network protocol |
| Client/server simulation | один игровой процесс у host |
| State synchronization | не требуется — state существует только у host |
| Matchmaking | Steam friend/invite flow Remote Play, не PvZ matchmaking |
| NAT traversal | скрыт внутри Steam Remote Play |
| Latency compensation | input/video streaming layer Steam |
| Anti-cheat для PvP | специальный PvZ anti-cheat публично не документирован и для local/streamed PvP в нем нет обычной необходимости |

Официальные системные требования Replanted даже указывают `Online Connection Requirements: N/A`; Steam-функция Remote Play накладывается поверх локальной игры. citeturn220288search3

Есть, однако, **ReplantedOnline** — сторонний open-source мод, который создает настоящий online P2P. Он требует MelonLoader и BloomEngine, компилируется на .NET 8 и использует Harmony patches. Его repository structure содержит `ReloadedMatchmaking`, `ReplantedLobby`, transport layer, network routing, RPC, gameplay network objects и собственные `PacketWriter`/`PacketReader`. citeturn596546view0

Это очень полезный архитектурный референс: проект отдельно патчит networked gameplay, plant logic и zombie logic, то есть авторы пришли к тому же выводу, что и Online-Battle для старой игры — необходимо синхронизировать **семантические игровые события**, а не пытаться stream'ить весь process state. citeturn596546view0turn981322search0

## Варианты сетевой архитектуры для PvZ 2009

С точки зрения реализации есть четыре разумных пути.

| Подход | Плюсы | Минусы | Сложность | Типичная latency | Cheat surface | Что нужно пользователю |
|---|---|---|---|---|---|---|
| Local split/shared screen | нет сети; минимум desync; проще отладка | требуется переработка input/UI | низкая–средняя | ≈0 | минимальная | controller/2 input devices |
| Raw TCP/UDP P2P | полный контроль; нет внешней платформы | NAT/firewall; IP disclosure; matchmaking отсутствует | средняя | низкая в LAN, зависит от Internet | высокая при доверии обоим peers | host IP/port, иногда port forwarding |
| Steam P2P/SDR | NAT traversal, Steam IDs, encrypted relays | Steamworks/AppID constraints; платформенная зависимость | средняя–высокая | обычно хорошая | средняя | Steam client + соответствующая лицензия |
| Собственный relay/client-server | контроль, hide IP, authoritative host/server | серверы, эксплуатация, auth, расходы | высокая | +relay hop | низкая при authoritative model | аккаунт/launcher/Internet |

**Local two-player** — полезнейший первый milestone. Вам надо разделить input context: PlantPlayer и ZombiePlayer либо Player1/Player2 в co-op; определить, кто имеет seed bank, cursor, resource pool и selection state. Именно этот слой потом можно сетевизировать без изменения gameplay rules.

Для Internet PvP я рекомендую **host-authoritative command replication**:

```text
Client:
  input -> Command(seq, tick, type, payload)
          |
          v
Host:
  validate -> apply to authoritative Board
           -> Event(seq, authoritativeTick, result)
           -> broadcast
Client:
  apply confirmed event
  compare periodic checksum
```

PvZ не требует 60 Hz transform replication. Например, движение обычного зомби может продолжать симулироваться локально, если обе стороны стартовали из одинакового состояния; сеть передает события появления, размещения, removals, RNG seeds и значимые state transitions. Но из-за несовершенной детерминированности старого C++ кода я бы не полагался на чистый lockstep: animation timing, random calls, floating point, frame timing и пропущенные side effects могут вызвать drift.

Поэтому разумный протокол имеет два слоя: reliable ordered commands/events и periodic resynchronization. Минимальный packet header:

```cpp
struct NetHeader {
    uint32_t magic;       // e.g. 'PVZN'
    uint16_t version;
    uint16_t type;
    uint32_t sequence;
    uint32_t gameTick;
    uint32_t payloadSize;
    uint32_t crc32;
};
```

Команды лучше сериализовать не указателями и не memory dumps, а стабильными IDs:

```text
PlacePlant {
    playerId
    plantType
    gridX
    gridY
    imitaterType
}

SpawnZombie {
    playerId
    zombieType
    row
    spawnSlot
}

UseShovel {
    playerId
    objectNetId
}
```

Нужен собственный `NetObjectId`. Не следует передавать адрес `Plant*` — ASLR и allocator делают его локальным для конкретного процесса.

Для raw sockets TCP-код MVP может выглядеть так:

```cpp
// server
SOCKET listenFd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
bind(listenFd, ...);
listen(listenFd, 1);

SOCKET peer = accept(listenFd, nullptr, nullptr);

NetMessage msg = MakePlacePlant(...);
SendFramed(peer, Serialize(msg));

// client
SOCKET fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
connect(fd, ...);

for (;;) {
    NetMessage msg = RecvFramed(fd);
    QueueForGameThread(msg);
}
```

Главное здесь не Winsock, а thread boundary: network thread **не должен напрямую мутировать `Board`**. Пакет нужно положить в lock-free или mutex-protected queue и исполнять на игровом update thread, иначе легко получить race с `Plant::Update`, `Zombie::Update` и object deletion.

Для latency-sensitive действий UDP или GameNetworkingSockets логичнее TCP, но PvZ настолько медленный, что TCP вполне приемлем для раннего прототипа; существующий Online-Battle это подтверждает практикой, хотя его crash/desync issues показывают, что transport сам по себе проблему синхронизации не решает. citeturn342395search0

**Lockstep** подходит, если удастся добиться полного deterministic simulation: оба peers получают одинаковый RNG seed, выполняют команды на одном `tick N`, имеют фиксированный timestep и идентичный build. Тогда bandwidth почти нулевой. Но один расхожий RNG call ломает весь матч.

**Rollback** здесь обычно избыточен. Он требует snapshot всей релевантной state graph, повторного deterministic replay и корректной реставрации pointers/containers/animations. В файтингах это оправдано миллисекундной чувствительностью; для PvZ дешевле задержать удаленную placement-команду на 50–100 ms.

**State diffs/snapshots** полезнее как recovery layer: раз в секунду хост считает hash от списка plants/zombies, их type, row, x, health, timers и resource totals. При mismatch клиент запрашивает `StateSnapshot`, а хост пересоздает или корректирует объекты.

Steam Networking дает более удобный transport. Современный `ISteamNetworkingSockets` умеет P2P, а Steam Datagram Relay скрывает IP и обеспечивает encrypted/authenticated traffic; `ISteamNetworkingMessages` похож по модели на UDP и тоже умеет reliable delivery. citeturn227627search4turn558851search5

Псевдокод Steam P2P:

```cpp
SteamNetworkingIdentity host;
host.SetSteamID64(hostSteamId);

auto* sockets = SteamNetworkingSockets();

HSteamNetConnection conn =
    sockets->ConnectP2P(host, 0, 0, nullptr);

sockets->SendMessageToConnection(
    conn,
    bytes.data(),
    bytes.size(),
    k_nSteamNetworkingSend_Reliable,
    nullptr
);
```

На host:

```cpp
HSteamListenSocket listener =
    sockets->CreateListenSocketP2P(0, 0, nullptr);

// connection callback:
// accept remote SteamID
sockets->AcceptConnection(connection);
```

Steam документация действительно описывает `CreateListenSocketP2P` + `ConnectP2P` именно как P2P flow с relay через Valve network. citeturn227627search5

Но здесь есть серьезная продуктовая проблема: Steamworks SDK и backend features привязаны к AppID/application configuration. Valve пишет, что SDK получается после Steamworks onboarding; Steam API и ownership/auth работают в контексте AppID, а SDR использует app-specific authentication infrastructure. Открытый вариант GameNetworkingSockets доступен свободно, но Valve прямо отмечает, что open-source версия **не дает доступ к SDR relay network**. citeturn558851search1turn558851search3turn558851search5

Поэтому для независимого PvZ-мода нельзя строить план на предположении «мы просто включим Steam SDR для AppID 3590». Вы не контролируете Steamworks configuration PopCap/EA. Реалистичные варианты — raw sockets, независимый relay, либо выяснять отдельно, какие client-side Steam networking features реально работают в существующем AppID без publisher-side configuration.

## Reverse engineering, compatibility и безопасность

Для binary-injection варианта потребуется сначала создать **version abstraction**. Вместо жестких абсолютных адресов вроде `0x00412345` лучше использовать signature/AOB scanning: искать последовательность инструкций вокруг `Board::AddPlant`, `Board::AddZombieInRow`, `Board::Update`, game-mode initialization и input handlers. Это не сделает мод универсальным автоматически, но позволит пережить небольшое смещение functions между builds.

Минимальный набор hooks, вероятно, будет включать:

```text
Board creation / level initialization
Board::Update or equivalent tick
plant placement
zombie creation
plant removal / shovel
level end
seed-bank/input handlers
RNG initialization
pause / speed controls
object destruction where network IDs must be released
```

Online-Battle уже подтверждает необходимость hooks до/после loading level, slot initialization, CreatePlant, CreateZombie и LevelEnd. citeturn227627search6

DLL injection дает удобное место для Winsock, serialization и hook manager. Типовая схема:

```mermaid
flowchart TD
    EXE["PlantsVsZombies.exe"] --> INJ["Launcher / DLL injector"]
    INJ --> DLL["pvzmp.dll"]
    DLL --> SIG["Version detection + signature scan"]
    SIG --> HOOK["MinHook / inline detours"]
    HOOK --> GAME["Board / Plant / Zombie hooks"]
    DLL --> NET["Networking thread"]
    NET --> QUEUE["Command queue"]
    QUEUE --> GAME
```

MinHook подходит для x86 hooks; существующие PvZ frameworks уже используют его. Для статически реконструированной версии hook layer вообще можно убрать и вызвать networking subsystem непосредственно из `Board`/input code. citeturn342395search12turn596546view1

В безопасности важнейшее правило: **никогда не доверять packet payload**, даже если соединение идет с другом. Host должен проверять `plantType`, coordinates, стоимость, cooldown, resources, доступность zombie и match phase. Любой malformed length должен отклоняться до allocation. Network packet не должен содержать arbitrary memory address или код.

Для Internet build добавьте protocol version, build fingerprint, feature flags и match nonce. При handshake сравнивайте:

```text
protocolVersion
pvzExecutableHash
modVersion
contentManifestHash
rulesetHash
randomSeed
```

Если hashes различаются, матч лучше не начинать. Это предотвращает трудно диагностируемые desync из-за разных `.pak`, plants tables или executable layouts.

Cheat model зависит от topology. В symmetric P2P оба клиента могут подменить memory. В host-authoritative PvP host все равно способен читерить, но remote client не может легально создать бесплатный Gargantuar или plant, если host валидирует команды. Настоящий anti-cheat потребовал бы dedicated authoritative server — слишком большой overhead для первой версии.

Отдельный dedicated server для оригинального PvZ сложен, потому что game simulation тесно связана с native client code и rendering/UI. Реалистичнее либо headless fork reconstructed codebase, либо «listen server» внутри host process.

Юридически reverse engineering и моддинг нужно рассматривать отдельно от технической возможности. EA User Agreement предоставляет ограниченную non-commercial license и прямо запрещает modification/distribution/reverse engineering, кроме случаев, когда это прямо разрешено EA или применимым законом; также отдельно оговариваются technical protection и unauthorized third-party programs. Поэтому наличие рабочего reverse engineering проекта не означает автоматического разрешения на его распространение. citeturn558851search6

Самая безопасная модель дистрибуции с точки зрения IP — **не распространять EA assets и оригинальный executable**. Именно такую модель используют re-plants-vs-zombies и PvZ-Portable: пользователь предоставляет ресурсы из собственной законно приобретенной копии, а проект распространяет только собственный код. citeturn596546view1turn594338search5

Также важно не смешивать anti-cheat Replanted/EA в эту оценку: публичных данных о специальном anti-cheat PvZ Replanted я не нашел, а официальный multiplayer там локальный/streamed. Общий EA User Agreement описывает право EA использовать anti-cheat в online-capable games, но это не доказательство того, что конкретно Replanted запускает kernel-level или аналогичный anti-cheat. citeturn558851search6turn220288search3

## Рекомендуемая реализация и прототипирование

Рекомендованный baseline — **Windows x86, C++20, CMake, Visual Studio 2022, MinHook, Winsock2 или standalone GameNetworkingSockets**, с первоначальной поддержкой **одной фиксированной версии PvZ**. Это почти полностью совпадает с proven toolchain существующего Online-Battle, но вместо множества абсолютных offsets стоит сразу заложить signature scanning и protocol abstraction. citeturn227627search6turn342395search12

Я бы строил код примерно так:

```text
pvzmp/
  hook/
    version_detector
    signatures
    board_hooks
    input_hooks

  game/
    game_api
    object_registry
    command_validator
    state_hash

  net/
    transport
      tcp_transport
      udp_transport
      steam_transport
    protocol
    serializer
    session

  ui/
    lobby
    connection_dialog

  launcher/
```

`game_api` должен стать единственным местом, где network code знает о PvZ internals. Например:

```cpp
class IGameApi {
public:
    virtual bool CanPlacePlant(PlayerId, PlantType, GridPos) = 0;
    virtual NetObjectId PlacePlant(PlantType, GridPos) = 0;
    virtual NetObjectId SpawnZombie(ZombieType, int row) = 0;
    virtual GameSnapshot BuildSnapshot() = 0;
};
```

Transport должен ничего не знать о `Board*`, а hook code — ничего о `SOCKET`. Это резко облегчит переход с TCP на Steam/GameNetworkingSockets.

Для serialization в первой версии не нужен Protobuf. Fixed-width little-endian binary packets с bounds-checked reader быстрее отлаживаются и проще внедряются в x86 DLL. После стабилизации можно перейти на FlatBuffers/MessagePack/Protobuf, если нужна backward compatibility.

Пример безопасного reader:

```cpp
template<class T>
bool Read(PacketReader& r, T& value) {
    if (r.remaining() < sizeof(T))
        return false;

    memcpy(&value, r.ptr(), sizeof(T));
    r.advance(sizeof(T));
    return true;
}
```

Для двух игроков bandwidth будет ничтожным. Даже 100 команд/сек по 64–128 bytes — порядка единиц килобайт в секунду. Основные performance risks находятся не в сети, а в hooking, thread synchronization, snapshot generation и ошибочном повторном создании game objects.

MVP следует сознательно ограничить одним режимом — например, Vs. на lawn map. Не пытайтесь одновременно поддерживать Adventure, Pool, Roof, co-op, I-Zombie и 10 версий executable. Именно существующий Online-Battle ограничился `I, Zombie Endless`, что существенно уменьшило reverse-engineering surface. citeturn342395search0

Разумная последовательность разработки:

```mermaid
gantt
    title PvZ Multiplayer Mod — последовательность разработки
    dateFormat  YYYY-MM-DD

    section Reverse engineering
    Зафиксировать целевой EXE и symbols map       :a1, 2026-11-03, 14d
    Найти Board/Input/CreatePlant/CreateZombie   :a2, after a1, 21d

    section Local multiplayer
    Абстракция PlayerInput                       :b1, after a2, 14d
    Локальный Vs. с двумя устройствами ввода     :b2, after b1, 21d

    section Network MVP
    Protocol + TCP transport                     :c1, after b2, 14d
    Host authoritative commands                  :c2, after c1, 21d
    State hash + snapshot recovery               :c3, after c2, 14d

    section Internet
    NAT/relay transport                          :d1, after c3, 21d
    Lobby/invite UI                              :d2, after d1, 14d

    section Hardening
    Version signatures                           :e1, after d2, 21d
    Fuzzing packets / compatibility tests        :e2, after e1, 21d
```

Практический план прототипа можно свести к одной последовательности:

1. Выбрать один target — я бы взял либо `1.0.0.1051`, чтобы легче переиспользовать Online-Battle research, либо Steam GOTY 1.2.0.1096, если конечная аудитория должна запускать мод прямо из Steam; PvZ-Portable документирует именно эту Steam build как отдельную supported version. citeturn342395search0turn594338search5
2. Склонировать Online-Battle, re-plants-vs-zombies и ResoddedFramework и составить таблицу `symbol → known address/offset/function semantics` для выбранного executable. citeturn227627search6turn596546view1turn596546view2
3. Сделать DLL, которая только логирует `CreatePlant` и `CreateZombie`, не меняя игру.
4. Добавить `NetObjectRegistry`, присваивающий объектам стабильный `uint32_t`.
5. Реализовать local dual-input Versus.
6. Заменить Player 2 input provider на localhost TCP connection.
7. Передавать только commands; хост выполняет validation и replay.
8. Добавить `StateHash` каждые ~30–60 game ticks и full snapshot по запросу.
9. После стабильного LAN теста заменить transport на UDP/GameNetworkingSockets или собственный relay.
10. Только после этого добавлять Steam lobby/invites, дополнительные versions и matchmaking.

Архитектурно итоговый MVP должен выглядеть так:

```mermaid
sequenceDiagram
    participant Z as Zombie client
    participant N as Network
    participant H as Plant host
    participant B as Authoritative Board

    Z->>N: SpawnZombie(seq=18,row=2,type=Bucket)
    N->>H: command
    H->>B: Validate cost/cooldown/rules

    alt valid
        B->>B: CreateZombie()
        H->>N: SpawnAccepted(seq=18,netId=472,tick=810)
        N->>Z: authoritative event
        Z->>Z: Create/confirm local zombie
    else invalid
        H->>N: Reject(seq=18,reason)
        N->>Z: rollback local UI prediction
    end

    H->>N: StateHash(tick=840,hash=...)
    N->>Z: StateHash
```

Для PvZ это намного более реалистично, чем классический shooter-style snapshot interpolation. Пользовательские действия редкие, объекты движутся предсказуемо, а небольшая задержка placement/spawn обычно не разрушает UX.

Итоговая техническая рекомендация: **для первой рабочей версии не копировать Replanted Remote Play и не пытаться сделать rollback; взять hook architecture Online-Battle, но заменить его хрупкую pairwise event sync на host-authoritative protocol с IDs, validation и periodic state repair.** Если в дальнейшем проект сможет перейти на reconstructed executable, лучше перенести networking непосредственно в C++ source tree Resodded/PvZ-Portable — это устраняет большую часть проблем с addresses, DLL injection и version compatibility. citeturn342395search0turn596546view2turn594338search5