#pragma once
namespace RoadLayout {
// zombie_map2.png, fitted to the native 1067x600 viewport.
constexpr int Left=336,Top=88,CellWidth=58,RowHeight=96,Columns=9,Rows=5;
constexpr int Width=CellWidth*Columns;
inline float spawnX(int col){return Left+CellWidth*0.5f+col*CellWidth;}
inline int bodyY(int row){return Top-40+row*RowHeight;}
}
