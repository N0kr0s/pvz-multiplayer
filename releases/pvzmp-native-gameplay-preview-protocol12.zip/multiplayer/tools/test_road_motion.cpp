#include "../hook/road-motion.h"
#include <cassert>
#include <cstdio>
int main(){
    assert(RoadMotion::speed(0)<0.6f && RoadMotion::speed(7)<1.0f);
    assert(RoadMotion::ExitX< -120);
    float x=478;unsigned ticks=0;
    while(x>RoadMotion::ExitX){assert(x> -160);x-=RoadMotion::speed(0);++ticks;}
    assert(ticks>2000 && x<=RoadMotion::ExitX);
    float decoded=0;
    assert(RoadMotion::decode((unsigned)-159000,decoded) && decoded== -159.0f);
    assert(RoadMotion::decode(960000,decoded) && decoded==960.0f);
    assert(!RoadMotion::decode((unsigned)-201000,decoded));
    assert(!RoadMotion::decode(1100001,decoded));
    puts("Road-only motion OK: slower deployment, fully offscreen transfer, signed wire positions.");
}
