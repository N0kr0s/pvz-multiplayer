#pragma once
#include "lan.h"
#include "match-ui.h"
struct Graphics;
bool engineInstall(LanService*,void (*log)(const char*));
void enginePoll(); // UI-thread timer, outside any widget Update/Draw.
void engineRequestStart();
bool engineActive();
bool engineStarting();
void engineLeave();
bool engineInput(unsigned message,unsigned key,int x,int y);
void engineDraw(Graphics*);
const char* engineStatus();
const Match::StateData* engineState();
int engineRole();

bool engineHover(MatchUI::Cell*);
bool engineMenuHover();
