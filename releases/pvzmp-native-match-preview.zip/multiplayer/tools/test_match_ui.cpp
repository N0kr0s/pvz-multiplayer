#include <initializer_list>
#include "../hook/ip-addresses.h"
#include "../hook/match-ui.h"
#include <assert.h>
#include <stdio.h>
int main(){
    char ip[128]="";
    for(const char* candidate:{"127.0.0.1","0.0.0.0","169.254.2.1","100.75.133.117","192.168.31.151","192.168.31.151"})LanIP::consider(ip,sizeof(ip),candidate);
    assert(!strcmp(ip,"192.168.31.151"));
    for(const char* invalid:{"","1.2.3","1.2.3.4.5","999.0.0.1","1..2.3","-1.2.3.4","1.2.3.a","0000.1.2.3"})assert(!LanIP::rank(invalid));
    char fallback[128]="";LanIP::consider(fallback,sizeof(fallback),"100.75.133.117");assert(!strcmp(fallback,"100.75.133.117"));
    assert(LanIP::rank("172.16.0.1")>LanIP::rank("100.75.133.117"));
    assert(MatchUI::menuAt(965,8) && MatchUI::menuAt(1054,40));
    assert(!MatchUI::menuAt(964,8) && !MatchUI::menuAt(1055,40) && !MatchUI::menuAt(965,41));
    for(int row=0;row<5;++row)for(int col=0;col<9;++col){
        int x=40+80*col,y=80+100*row;
        assert(MatchUI::inside(x,y,x,y,80,100));assert(MatchUI::inside(x+79,y+99,x,y,80,100));
        assert(!MatchUI::inside(x+80,y,x,y,80,100));assert(!MatchUI::inside(x,y+100,x,y,80,100));
    }
    puts("LAN address preference and HUD/tile boundaries OK.");
}
